package Testpack;

public class TestExmp {

	public static void main(String[] args) {
		TestExmp te1= new TestExmp();
		TestExmp te2= new TestExmp();
		
		int m1= te1.hashCode();
		int m2= te2.hashCode();
		
	System.out.println("Hash Code of e1 is:"+m1);
	System.out.println("Hash Code of e2 is:"+m2);
	if(te1.equals(te2))
	{
		System.out.println("Objects are Equal...");
	}
	else
	{
		System.out.println("Objects are Not Equal...");
	}

	}
}

