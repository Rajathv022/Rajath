package com.niit.dao;

import com.niit.model.Cart;

public interface CartDAO {

	public void addCart(Cart cart);
}
