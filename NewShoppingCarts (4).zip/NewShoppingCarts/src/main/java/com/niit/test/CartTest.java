package com.niit.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.dao.CartDAO;
import com.niit.model.Cart;


public class CartTest 
{
	public static void main(String[] args) 
	{
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		
		CartDAO cartDAO = (CartDAO) context.getBean("cartDAO");
		System.out.println("success");
		Cart cart=(Cart) context.getBean("cart");
		
		cart.setId(16);
		cart.setPrice(15000);
		cart.setProduct_id("002");
		cart.setStatus("tyhss");
		cart.setQuantity(1);
		cart.setUser_id("12345");
		
		cartDAO.addCart(cart);

	}

}