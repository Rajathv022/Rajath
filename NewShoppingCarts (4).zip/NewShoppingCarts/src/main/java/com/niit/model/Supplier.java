package com.niit.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.stereotype.Component;

@Entity 
@Table(name="Supplier")
@Component
 public class Supplier
{
		@Id
		private String id;
       
	   @NotEmpty(message="please enter name")
       private String name;
       
       @NotEmpty(message="please enter phone")
       private String phone;
       
       @NotEmpty(message="please enter address")
       private String address;
       
       // This is used to supply the products from the cart list//
       public String getId() {
   		return id;
   	}

   	public void setId(String id) {
   		this.id = id;
   	}

   	public String getName() {
   		return name;
   	}

   	public void setName(String name) {
   		this.name = name;
   	}

   	public String getPhone() {
   		return phone;
   	}

   	public void setPhone(String phone) {
   		this.phone = phone;
   	}
   	
   	public String getAddress() {
   		return address;
   	}

   	public void setAddress(String address) {
   		this.address = address;
   	}

	


}

