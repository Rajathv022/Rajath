package com.niit.dao;

import com.niit.config.User;

public interface UserDAO 
{
public void addUser(User user);
}
