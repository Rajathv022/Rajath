package com.niit.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.dao.CartDAO;
import com.niit.model.Cart;


public class CartTest 
{
	public static void main(String[] args) 
	{
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		
		CartDAO cartDAO = (CartDAO) context.getBean("cartDAO");
		System.out.println("success");
		Cart cart=(Cart) context.getBean("cart");
		
		cart.setId(01);
		cart.setPrice(55);
		cart.setProduct_id("001");
		cart.setStatus("ijuy");
		cart.setQuantity(1);
		cart.setUser_id(263);
		
		cartDAO.addCart(cart);

	}

}