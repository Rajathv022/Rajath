package DataPack;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class TestConnection {

	public static void main(String[] args) throws Exception 
	{
		Class.forName("org.h2.Driver");
		Connection con = DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test","sa","");
		PreparedStatement pst = con.prepareStatement("insert into customer values(202,'Rajath','MVM',9845555)");
		pst.executeUpdate();
		pst.close();
		con.close();
		
		System.out.println("DATA IS ADDED.....");

	}

}
